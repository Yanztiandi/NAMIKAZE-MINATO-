const form = document.querySelector('#download-form');
const input = document.querySelector('#video-url');
const pasteBtn = document.querySelector('#paste-btn');
const note = document.querySelector('#form-note');
const resultWrap = document.querySelector('#result-wrap');
const skeleton = document.querySelector('#skeleton-card');
const result = document.querySelector('#demo-result');
const toast = document.querySelector('#toast');
let toastTimer;

function showToast(message) {
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('show'), 2500);
}

pasteBtn.addEventListener('click', async () => {
  try {
    if (!navigator.clipboard?.readText) throw new Error('Clipboard tidak tersedia');
    const text = await navigator.clipboard.readText();
    if (!text) return showToast('Clipboard masih kosong.');
    input.value = text;
    input.focus();
    showToast('Tautan berhasil ditempel.');
  } catch {
    input.focus();
    showToast('Tempel tautan secara manual (Ctrl/tekan lama).');
  }
});

form.addEventListener('submit', (event) => {
  event.preventDefault();
  const value = input.value.trim();
  if (!value) {
    input.focus();
    return showToast('Masukkan tautan TikTok terlebih dahulu.');
  }
  let url;
  try { url = new URL(value); } catch { return showToast('Format tautan belum valid.'); }
  if (!/(^|\.)tiktok\.com$/i.test(url.hostname)) {
    return showToast('Gunakan tautan dari domain TikTok.');
  }
  resultWrap.hidden = false;
  skeleton.hidden = false;
  result.hidden = true;
  note.textContent = 'Memeriksa format tautan…';
  window.setTimeout(() => {
    skeleton.hidden = true;
    result.hidden = false;
    note.textContent = 'Demo frontend saja — belum terhubung ke layanan pengunduh.';
  }, 950);
});

document.querySelector('#year').textContent = new Date().getFullYear();
