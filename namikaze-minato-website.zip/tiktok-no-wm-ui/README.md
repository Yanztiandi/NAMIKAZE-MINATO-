# NAMIKAZE MINATO — TikTok Downloader UI

Frontend statis untuk GitHub Pages. Saat ini hanya UI/demo: belum ada API atau proses pengunduhan yang terhubung.

## Jalankan lokal
Buka `index.html` di browser, atau jalankan server lokal:

```bash
python -m http.server 8000
```

Lalu buka `http://localhost:8000`.

## Deploy ke GitHub Pages
1. Buat repository GitHub baru.
2. Upload seluruh isi folder ini (pastikan `index.html` berada di root repository).
3. Buka **Settings → Pages**.
4. Pada **Build and deployment**, pilih **Deploy from a branch**.
5. Pilih branch `main`, folder `/ (root)`, lalu **Save**.

## Catatan
- `assets/hero-minato.jpg` adalah gambar yang diberikan untuk desain.
- Tombol dan validasi tautan berjalan sebagai demo UI; tidak mengambil atau mengunduh video.
- Integrasikan backend/API milikmu nanti, dan pastikan penggunaan mematuhi hak cipta, izin kreator, serta ketentuan platform.
