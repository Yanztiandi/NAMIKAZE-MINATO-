export default async function handler(req, res) {
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return res.status(405).json({ error: "Method tidak diizinkan." });
  }

  const videoUrl = String(req.body?.url || "").trim();

  let parsed;
  try {
    parsed = new URL(videoUrl);
  } catch {
    return res.status(400).json({ error: "Masukkan URL TikTok yang valid." });
  }

  const host = parsed.hostname.toLowerCase();
  if (parsed.protocol !== "https:" || !(host === "tiktok.com" || host.endsWith(".tiktok.com"))) {
    return res.status(400).json({ error: "Masukkan URL TikTok yang valid." });
  }

  try {
    const endpoint = new URL("https://www.tiktok.com/oembed");
    endpoint.searchParams.set("url", videoUrl);

    const response = await fetch(endpoint, {
      headers: { "User-Agent": "Mozilla/5.0 NamikazeMinato/1.1" },
      signal: AbortSignal.timeout(12000)
    });

    if (!response.ok) {
      return res.status(502).json({
        error: "Preview belum tersedia dari TikTok. Periksa link atau buka video aslinya."
      });
    }

    const data = await response.json();
    return res.status(200).json({
      title: data.title || "TikTok video",
      author: data.author_name || "TikTok creator",
      authorUrl: data.author_url || "",
      thumbnail: data.thumbnail_url || "",
      sourceUrl: videoUrl
    });
  } catch (error) {
    console.error("TikTok preview error:", error?.message || error);
    return res.status(502).json({
      error: "Tidak bisa mengambil preview dari TikTok saat ini. Coba lagi nanti."
    });
  }
}
