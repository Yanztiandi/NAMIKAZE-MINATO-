# MINATO NAMIKAZE — Vercel Edition

Versi Vercel dari website MINATO NAMIKAZE. Tampilan frontend, CSS, JavaScript, dan gambar Minato dipertahankan dari versi sebelumnya. Backend Express/Pterodactyl diganti menjadi Vercel Serverless Function.

## Deploy paling mudah

1. Ekstrak ZIP ini.
2. Upload folder `NAMIKAZE-MINATO-VERCEL` ke GitHub sebagai repository baru.
3. Buka https://vercel.com dan login menggunakan GitHub.
4. Pilih **Add New → Project**, lalu Import repository tadi.
5. Biarkan Framework Preset **Other**. Jangan isi Build Command atau Output Directory.
6. Klik **Deploy**.
7. Setelah selesai, buka URL `.vercel.app` yang diberikan Vercel.

## Fitur yang dipertahankan

- Tampilan MINATO NAMIKAZE dan gambar Minato.
- Form tempel link TikTok dan tombol preview.
- Preview judul, kreator, dan thumbnail melalui TikTok oEmbed.
- Riwayat link di browser (localStorage).
- Tombol paste clipboard.
- Simpan file video lokal dari perangkat.
- Responsive layout dan animasi yang sudah ada.

## Catatan penting

Fitur preview mengambil metadata dari endpoint resmi TikTok oEmbed. Versi sumber sebelumnya **belum memiliki mesin pengunduh video TikTok tanpa watermark**. Karena itu, ZIP ini mempertahankan fungsi yang memang sudah ada dan tidak mengklaim bahwa tombol preview bisa mengunduh video TikTok. Fitur simpan file lokal hanya menyimpan file video yang dipilih dari perangkat pengguna.

Tidak perlu mengatur port, Node server, atau Pterodactyl. Vercel menjalankan `api/preview.js` sebagai serverless function.
