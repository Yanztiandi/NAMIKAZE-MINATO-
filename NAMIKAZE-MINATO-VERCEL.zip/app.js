const form = document.querySelector("#link-form");
const urlInput = document.querySelector("#video-url");
const previewButton = document.querySelector("#preview-button");
const skeleton = document.querySelector("#skeleton");
const previewCard = document.querySelector("#preview-card");
const message = document.querySelector("#message");
const historyList = document.querySelector("#history-list");
const HISTORY_KEY = "namikaze-minato-history";

document.querySelector("#year").textContent = new Date().getFullYear();

function setLoading(loading) {
  previewButton.classList.toggle("loading", loading);
  previewButton.disabled = loading;
  skeleton.hidden = !loading;
  if (loading) previewCard.hidden = true;
}

function isTikTokLink(value) {
  try {
    const host = new URL(value).hostname;
    return ["tiktok.com", "www.tiktok.com", "vm.tiktok.com", "vt.tiktok.com"].includes(host);
  } catch { return false; }
}

function getHistory() {
  try { return JSON.parse(localStorage.getItem(HISTORY_KEY) || "[]"); }
  catch { return []; }
}

function renderHistory() {
  const items = getHistory();
  if (!items.length) {
    historyList.innerHTML = '<div class="empty-state">Belum ada tautan yang dipreview.</div>';
    return;
  }
  historyList.replaceChildren();
  items.forEach((url) => {
    const row = document.createElement("div");
    row.className = "history-item";
    const label = document.createElement("span");
    label.className = "history-url";
    label.textContent = url;
    const link = document.createElement("a");
    link.className = "history-open";
    link.href = url;
    link.target = "_blank";
    link.rel = "noopener noreferrer";
    link.textContent = "Open ↗";
    row.append(label, link);
    historyList.append(row);
  });
}

function saveHistory(url) {
  const next = [url, ...getHistory().filter((item) => item !== url)].slice(0, 5);
  localStorage.setItem(HISTORY_KEY, JSON.stringify(next));
  renderHistory();
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  const url = urlInput.value.trim();
  message.textContent = "";
  if (!isTikTokLink(url)) {
    message.textContent = "Masukkan link TikTok yang valid terlebih dahulu.";
    return;
  }

  setLoading(true);
  try {
    const response = await fetch("/api/preview", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Preview gagal dimuat.");

    document.querySelector("#preview-title").textContent = data.title;
    document.querySelector("#preview-author").textContent = `By ${data.author}`;
    document.querySelector("#preview-thumb").src = data.thumbnail || "";
    document.querySelector("#source-link").href = data.sourceUrl;
    previewCard.hidden = false;
    saveHistory(url);
  } catch (error) {
    message.textContent = error.message || "Terjadi kesalahan. Coba lagi.";
  } finally {
    setLoading(false);
  }
});

document.querySelector("#paste-button").addEventListener("click", async () => {
  try {
    urlInput.value = await navigator.clipboard.readText();
    urlInput.focus();
  } catch {
    message.textContent = "Clipboard tidak bisa diakses. Tempel link secara manual.";
  }
});

const fileInput = document.querySelector("#file-input");
document.querySelector("#choose-file").addEventListener("click", () => fileInput.click());
fileInput.addEventListener("change", () => {
  const file = fileInput.files?.[0];
  const fileName = document.querySelector("#file-name");
  if (!file) return;
  if (!file.type.startsWith("video/")) {
    fileName.textContent = "Pilih file video yang valid.";
    return;
  }
  const objectUrl = URL.createObjectURL(file);
  const anchor = document.createElement("a");
  anchor.href = objectUrl;
  anchor.download = file.name || "my-video";
  document.body.append(anchor);
  anchor.click();
  anchor.remove();
  fileName.textContent = `File tersimpan dari perangkat: ${file.name}`;
  setTimeout(() => URL.revokeObjectURL(objectUrl), 30000);
});

document.querySelector("#clear-history").addEventListener("click", () => {
  localStorage.removeItem(HISTORY_KEY);
  renderHistory();
});

renderHistory();